# Suci Sekar Ayu — Personal Website

A minimalist, responsive, green-and-white personal portfolio.

## Publish via GitHub Pages

1. Upload `index.html` to the root of the repository `sucisekarayu-spec/sucisekar` on the `main` branch.
2. In repository **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
3. After GitHub finishes publishing, the expected site URL is: https://sucisekarayu-spec.github.io/sucisekar/

The URL is **not confirmed live** until GitHub Pages deployment succeeds.

## Update

Edit text in `index.html`. Replace the decorative `S` illustration with a personal photograph if desired. The website includes no private phone number, personal email, or sensitive medical details.

## Public sources

- https://online.binus.ac.id/palembang/
- https://id.linkedin.com/in/suci-sekar-ayu-5b3542237
- https://hidayatkampai.com/2025/05/24/pkm-binus-learning-community-palembang-cara-mudah-menentukan-harga-jual-produk-yang-tepat/
